<?php
function imprimir($a){
	for($i=0; $i<=count($a) ; $i++) {
echo $a[$i].' ';
}
}
function selection_sort($array) {
	$len = count($array) -1;
	for($i=0; $i<=$len ; $i++) {
		imprimir($array);echo "<br>";
		$ini = $i;
		for($j=$i+1; $j<=$len; $j++) {
			if ($array[$j] < $array[$i]) {
				$ini = $j;
			}
		}
		if ($ini != $i) {
			$troca = $array[$i];
			$array[$i] = $array[$ini];
			$array[$ini] = $troca;
		}
	}
	return $array;
}
selection_sort(array(3,15,6,12,14,8,1,34));
//echo 'as';
//print_r(selection_sort(array(3,2)));
//echo 'a';
