function isqueParse(funcion){
		var a = funcion;
// 		console.log(a,'funcion A');
		while(a.search(' ')!=-1)
			a = a.replace(' ','');
// console.log(6);
		while(a.search('sin')!=-1)
			a = a.replace(/sin/i,'S');
// console.log(9);
		while(a.search('cos')!=-1)
			a = a.replace(/cos/i,'C');
// console.log(12);
		while(a.search('ln')!=-1)
			a = a.replace(/ln/i,'L');
// console.log(a,'A15');
		while(a.search('t')!=-1)
			a = a.replace('t','T');
// console.log(a,'A18');
		var tmpa = "";
		for(var i=a.length;i>=0;i--){
			tmpa += a.charAt(i);
		}
		a = tmpa;//0SSS
// console.log(a,'funcion A');
// 		console.log(tmpa,'tmpa');
		while(a.search('S')!=-1){
				var n = a.search('S');
				var p = a.charAt(n-1);
				if(p)
					if(p!='('){
							
							///)0S
							var ca= 0;var l=0;var fv = false;//console.log(a,'a 26');
							for(var i=n-1;i>=0;i--){
								var tmpp = a.charAt(i);//console.log(tmpp,'tmpp');
								if(fv)
									if(tmpp == '(')
										continue;

// 								console.log(i,'i');
								if(tmpp == '+' || tmpp == ')' || tmpp == '-' || tmpp == '*' || tmpp == '/' || tmpp == '%'){console.log(ca,'CA');
									if(ca==0){
										l = i+1;
										break;
									}
									else
										ca--;
								}
								if(tmpp == '(' || tmpp == 's' )
									ca++;
								if(tmpp == 's' || tmpp == 'C')
									fv = true;
							}console.log(l,'L');
							tmpa = "";//console.log(a,'a 32');
							for(var i=0;i<=a.length;i++){
								if(i==l)
									tmpa += ")";
								//else
									tmpa += a.charAt(i);
							}
							a = tmpa;//console.log(a,'a 39');
							a = a.replace('S','(S');
						}
				a = a.replace('S','s');
		}

		var tmpa = "";
		for(var i=a.length;i>=0;i--){
			tmpa += a.charAt(i);
		}
		a = tmpa;
			

		while(a.search('s')!=-1)
			a = a.replace('s','S');

		while(a.search('S')!=-1)
			a = a.replace('S','Math.sin');


		while(a.search('C')!=-1)
			a = a.replace('C','Math.cos');

		while(a.search('L')!=-1)
			a = a.replace('L','Math.log');

		return a;
	}

function reemplazarvariable(funcion,numero){
	while(funcion.search('T')!=-1)
		funcion = funcion.replace('T','X');

	while(funcion.search('X')!=-1)
		funcion = funcion.replace('X',numero);
// 	console.log(funcion,'TT');
	return funcion;
}
var sin = [], cos = [];
function graficar(){
var stringUsuario = $("#terminal").val();
	var stringJs = isqueParse(stringUsuario);

console.log(stringJs,'stringJs');
		//sin = [], cos = [];
	semilla = 0.2;
	j = semilla;
	j2 = j;
	/*
	error = 0.01;
	delta = 1;
    for (var i = 0; i < 150*delta; i += delta) {
	    tmp = eval(reemplazarvariable(stringJs,j));
	    sin.push([i,tmp]);
	    j = tmp;
	
	    tmp2 = eval(reemplazarvariable(reemplazarvariable(stringJs,'(T+'+error+')'),j2));
	    cos.push([i, tmp2]);
	    j2 = tmp2;
			//cos.push([i, reemplazarvariable(stringJs,'(t+5)')]);
			//cos.push([i,0]);
	//cos.push([i,0]);
    }*/
	
	var k = 0.99;
	var semilla = 0.2;
	var error = 0.001;
	var tmp = error+semilla;
	var tmp2 = semilla;
	for (var i = 0; i < 150; i++) {
	  sin.push([i,tmp]);
	  cos.push([i,tmp2]);
	  tmp = 4*k*tmp*(1-tmp);
	  tmp2 = 4*k*tmp2*(1-tmp2);
	  
	}
	
	var Atres = [];
	var Atres2 = [];
	//sin[2][1]
	for (var i = 0; i < 149; i++) {
	  Atres.push([cos[i][1],cos[i+1][1]]);
	  Atres2.push([cos[i+1][1],cos[i][1]]);
	}
	
	
	var A = [];
	var A2 = [];
	
	for (var i = 0; i < 140; i++) {
	    A.push([cos[i][1],cos[i+1][1]]);
	    A2.push([cos[i+1][1],cos[i+2][1]]);
	}
	
console.log(sin,'Arreglo sin');
console.log(cos,'Arreglo cos');
console.log(Atres,'Arreglo Atres');


    plot = $.plot($("#placeholder"),
                      [ { data: sin, label: "f(t) = -0.00"},
			{ data: cos, label: "f(t+e) = -0.00" } ], {
                            series: {
                                lines: { show: true }
                            },
                            crosshair: { mode: "x" },
                            grid: { hoverable: true, autoHighlight: false }
                        });
    
    plot2 = $.plot($("#placeholder2"),
                      [ { data: Atres, label: "f(t) = -0.00"},
		   { data: Atres2, label: "f(t) = -0.00"}
			], {
                            series: {
                                lines: { show: false },
				points: { show: true }
                            },
                            crosshair: { mode: "x" },
                            grid: { hoverable: true, autoHighlight: false }
                        });
    
        plot3 = $.plot($("#placeholder3"),
                      [ { data: Atres, label: "f(t) = -0.00"},
		   { data: Atres2, label: "f(t) = -0.00"}
			], {
                            series: {
                                lines: { show: true},
				points: { show: false }
                            },
                            crosshair: { mode: "x" },
                            grid: { hoverable: true, autoHighlight: false }
                        });
    
    var legends = $("#placeholder .legendLabel");
    legends.each(function () {
        // fix the widths so they don't jump around
        $(this).css('width', $(this).width());
    });

    var updateLegendTimeout = null;
    var latestPosition = null;
    
    function updateLegend() {
        updateLegendTimeout = null;
        
        var pos = latestPosition;
        
        var axes = plot.getAxes();
        if (pos.x < axes.xaxis.min || pos.x > axes.xaxis.max ||
            pos.y < axes.yaxis.min || pos.y > axes.yaxis.max)
            return;

        var i, j, dataset = plot.getData();
        for (i = 0; i < dataset.length; ++i) {
            var series = dataset[i];

            // find the nearest points, x-wise
            for (j = 0; j < series.data.length; ++j)
                if (series.data[j][0] > pos.x)
                    break;
            
            // now interpolate
            var y, p1 = series.data[j - 1], p2 = series.data[j];
            if (p1 == null)
                y = p2[1];
            else if (p2 == null)
                y = p1[1];
            else
                y = p1[1] + (p2[1] - p1[1]) * (pos.x - p1[0]) / (p2[0] - p1[0]);

            legends.eq(i).text(series.label.replace(/=.*/, "= " + y.toFixed(2)));
        }
    }
    
    $("#placeholder").bind("plothover",  function (event, pos, item) {
        latestPosition = pos;
        if (!updateLegendTimeout)
            updateLegendTimeout = setTimeout(updateLegend, 50);
    });
}

function boton_enter(e){
	if(e.keyCode == 13)
		graficar();
}

var selection = 0;
function getSelectionStart(o) {
	if (o.createTextRange) {
		var r = document.selection.createRange().duplicate()
		r.moveEnd('character', o.value.length)
		if (r.text == '') return o.value.length
		return o.value.lastIndexOf(r.text)
	} else return o.selectionStart
}

function boton_escribir(txt){
	var str = $("#terminal").val();
	var a = str.substring(0,selection);
	var b = str.substring(selection,str.length);
	str = a + txt + b;
	$("#terminal").val(str);
	selection+=txt.length;
}
var delta = 0.1;
var error = 5;
$(document).ready(function(){
	$("#terminal").keypress(boton_enter);
	selection = $("#terminal").val().length;
});