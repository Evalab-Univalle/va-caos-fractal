function Punto(x1,y1){
  this.x = x1;
  this.y = y1;
}

Punto.prototype ={
	 proximoX :function(angulo,distancia){
		return this.x+(Math.cos(angulo)*distancia);
	 },
	 proximoY:function(angulo,distancia){
		return this.y+(Math.sin(angulo)*distancia);
	 }
}

function Canvas(nombreCanvas){
  this.obj = document.getElementById(nombreCanvas);
  this.jobj = $(this.obj);
  this.width = this.jobj.width();
  this.height = this.jobj.height();
  this.ctx = this.obj.getContext("2d");
}

Canvas.prototype ={  
  dibujarLinea: function(xi,yi,xf,yf){
//   console.log('xi= '+xi+',yi= '+yi+',xf= '+xf+',yf= '+yf,'dibujarLinea');
  if(xf>this.width && yf>this.height && xi<0 && yi < 0)
	 return false;  
  
   if (this.ctx){ 
		this.ctx.beginPath();
		this.ctx.moveTo(xi,yi);
		this.ctx.lineTo(xf,yf);
		this.ctx.stroke();
	 }
  },
 limpiarLienzo: function(){  
  if(this.ctx)
	 this.ctx.clearRect(0,0,this.width,this.height);
  }
};

function Fractal(canvas,angulo,axioma,objGramatica){
  this.canvas = new Canvas(canvas);
  this.punto_inicial = new Punto(this.canvas.width/2,this.canvas.height/2);  
  this.num_iteracion = 0;
  this.longitud_linea = this.canvas.width/4;  
  this.lindenmayer = axioma;
  this.min_longitud = 1;
  this.delta_zoom = 5;
  this.mouseX = 0;
  this.mouseY = 0;
  this.intOverallDelta = 0;
	this.angulo = angulo;console.log(this.angulo,'this.angulo');
	this.objGramatica = objGramatica;
}

Fractal.prototype ={
  aumentar : function(){
	 this.longitud_linea+=this.delta_zoom;
  },
  disminuir : function(){
	 if(this.longitud_linea>this.min_longitud)
		this.longitud_linea-=this.delta_zoom;
  },
  fractalizar: function(){
	 if(this.num_iteracion<=7){
		this.num_iteracion++;
		this.longitud_linea = this.longitud_linea/3;
		this.lindenmayer = this.calcularSistema(this.lindenmayer);
		this.pintar();
	 }
  },
  mover: function(movX,movY){
	 var nuevoPunto = new Punto(this.punto_inicial.x-movX,this.punto_inicial.y-movY);
	 this.punto_inicial = nuevoPunto; 
  },
  clickmouseup: function(e){
	 var movimientoX =  this.mouseX - e.clientX;
	 var movimientoY =  this.mouseY - e.clientY;
	 this.mover(movimientoX,movimientoY);
	 this.pintar();
  },
  clickmousedown : function(e){
	 this.mouseX = e.clientX;
	 this.mouseY = e.clientY;
  },
  calcularSistema: function(sistema){
	 var nuevoSistema = "";
	 for(var i=0;i<sistema.length;i++){
		var accion = sistema.substring(i,i+1);
		if(accion=='F'){
			var borrar =  eval("this.objGramatica."+accion);
			nuevoSistema+=borrar;
		}
		else
			 nuevoSistema+=accion;
	 }
	 return nuevoSistema;
  },
  pintar: function(){
	 var then = new Date();
	 var puntoActual = this.punto_inicial;
	 var angulo = 0;
	 var distancia = this.longitud_linea;
	 this.canvas.limpiarLienzo();
	 for(var i=0;i<this.lindenmayer.length;i++){
		var accion = this.lindenmayer.substring(i,i+1);
		if(accion=='F'){
		  var xSiguiente = puntoActual.proximoX(angulo,distancia);
		  var ySiguiente = puntoActual.proximoY(angulo,distancia);
		  this.canvas.dibujarLinea(puntoActual.x,puntoActual.y,xSiguiente,ySiguiente);
		  puntoActual = new Punto(xSiguiente,ySiguiente);
		}
		else if(accion=='-')
		  angulo -= this.angulo;
		else if(accion=='+')
		  angulo += this.angulo;
	 }
	 var now = new Date();
//  	 console.log(" Dibujando >"+(now-then)+"ms",'TIME');
  },
  movewheel: function(objEvent,intDelta){
	 if (intDelta > 0){
		this.intOverallDelta++;
		this.aumentar();
		this.mover((objEvent.clientX-200)/40,(objEvent.clientY-200)/40);
	 }
	 else if (intDelta < 0){
		this.intOverallDelta--;
		this.disminuir();
		this.mover((objEvent.clientX-200)/40,(objEvent.clientY-200)/40);
	 }
	 this.pintar();
  }
};

var objFractal;

function fractal_accion(accion){
// 	if(!objFractal)
// 		return false;
	
	switch(accion){
		case 'koch':
// 			reglas = {'F':'F-F++F-F'};
// 			$('#fra_grados').val('60');
		break;
		case 'simular':
			var grados = parseInt($('#fra_grados').val());
			if(isNaN(grados))
				return false;
			grados = 180/grados;
			var reglas = {};
			var tabla = $("#tbl_reglas tr");
			var nots = $("#tbl_reglas [name='not']");
			var ters = $("#tbl_reglas [name='ter']");
			for(var i=0;i<tabla.length;i++)
				reglas[$(nots[i]).html()] = $(ters[i]).html();
			console.log(reglas,'Regalas');console.log(grados,'grados');
			objFractal = new Fractal('MiCanvas',Math.PI/grados,$('#fra_inicio').val(),reglas);
			objFractal.pintar();
			$('#MiCanvas').unbind('dblclick').dblclick(function(){objFractal.fractalizar();}); 
			$('#MiCanvas').unbind('mousedown').mousedown(function(e){objFractal.clickmousedown(e);});  
			$('#MiCanvas').unbind('mouseup').mouseup(function(e){objFractal.clickmouseup(e);});
			$('#MiCanvas').unbind('mousewheel').mousewheel(function(objEvent,intDelta){objFractal.movewheel(objEvent,intDelta);});
		break;
	}
}
 
$(document).ready(function(){
 	$("#slider").slider({orientation: 'vertical',disabled: true});
	$("#sel_funcion").val("0").change(function(){
		switch($(this).val()){
			case "0":
				fractal_accion('simular');break;
			case "1":
				fractal_accion('koch');break;
			case "2":
				fractal_accion('sierpinski');break;
		}
	});
});