function Canvas(nombreCanvas){
  this.obj = document.getElementById(nombreCanvas);
  this.jobj = $(this.obj);
  this.width = this.jobj.width();
  this.height = this.jobj.height();
  this.ctx = this.obj.getContext("2d");
}

Canvas.prototype ={  
  dibujarLinea: function(xi,yi,xf,yf){
//   console.log('xi= '+xi+',yi= '+yi+',xf= '+xf+',yf= '+yf,'dibujarLinea');
  if(xf>this.width && yf>this.height && xi<0 && yi < 0)
	 return false;  
  
   if (this.ctx){ 
		this.ctx.beginPath();
		this.ctx.moveTo(xi,yi);
		this.ctx.lineTo(xf,yf);
		this.ctx.stroke();
	 }
  },
 limpiarLienzo: function(){  
  if(this.ctx)
	 this.ctx.clearRect(0,0,this.width,this.height);
  }
};