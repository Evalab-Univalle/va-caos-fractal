function Punto(x1,y1){
  this.x = x1;
  this.y = y1;
}

Punto.prototype ={
	 proximoX :function(angulo,distancia){
		return this.x+(Math.cos(angulo)*distancia);
	 },
	 proximoY:function(angulo,distancia){
		return this.y+(Math.sin(angulo)*distancia);
	 }
}
