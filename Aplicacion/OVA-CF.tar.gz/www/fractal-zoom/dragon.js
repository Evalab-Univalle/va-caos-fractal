function Dragon(canvas){  
  this.canvas = new Canvas(canvas);
  this.punto_inicial = new Punto(this.canvas.width/4,3*this.canvas.height/4);
  //this.punto_inicial = new Punto(100,100);
  this.num_iteracion = 0;
  this.longitud_linea = this.canvas.width/2;
  //this.longitud_linea = 50;
  this.lindenmayer = "FX";
  this.min_longitud = 1;
  this.delta_zoom = 5;
  this.mouseX = 0;
  this.mouseY = 0;
  this.intOverallDelta = 0;
}

Dragon.prototype ={
  aumentar : function(){
	 this.longitud_linea+=this.delta_zoom;
  },
  disminuir : function(){
	 if(this.longitud_linea>this.min_longitud)
		this.longitud_linea-=this.delta_zoom;
  },
  fractalizar: function(){
	 if(this.num_iteracion<=100){
		this.num_iteracion++;
// 		this.longitud_linea = this.longitud_linea/4;
		this.lindenmayer = this.calcularSistema(this.lindenmayer);
// 		this.lindenmayer = this.calcularSistema(this.lindenmayer);
		this.pintar();
	 }
  },
  mover: function(movX,movY){
	 var nuevoPunto = new Punto(this.punto_inicial.x-movX,this.punto_inicial.y-movY);
	 this.punto_inicial = nuevoPunto; 
  },
  clickmouseup: function(e){
	 var movimientoX =  this.mouseX - e.clientX;
	 var movimientoY =  this.mouseY - e.clientY;
	 this.mover(movimientoX,movimientoY);
	 this.pintar();
  },
  clickmousedown : function(e){
	 this.mouseX = e.clientX;
	 this.mouseY = e.clientY;
  },
  calcularSistema: function(sistema){
	 var nuevoSistema = "";
	 for(var i=0;i<sistema.length;i++){
		var accion = sistema.substring(i,i+1);
		if(accion=='X')
			 nuevoSistema+="X+YF";
		else if(accion=='Y')
			 nuevoSistema+="FX-Y";
		else
			 nuevoSistema+=accion;
	 }
	 return nuevoSistema;
  },
  pintar: function(){
	 var then = new Date();
	 var puntoActual = this.punto_inicial;
	 var angulo = 0;
	 var distancia = this.longitud_linea;
	 this.canvas.limpiarLienzo();
	 for(var i=0;i<this.lindenmayer.length;i++){
		var accion = this.lindenmayer.substring(i,i+1);
		if(accion=='F'){
		  var xSiguiente = puntoActual.proximoX(angulo,distancia);
		  var ySiguiente = puntoActual.proximoY(angulo,distancia);
		  this.canvas.dibujarLinea(puntoActual.x,puntoActual.y,xSiguiente,ySiguiente);
		  puntoActual = new Punto(xSiguiente,ySiguiente);
		}
		else if(accion=='-')
		  angulo += Math.PI/2;
		else if(accion=='+')
		  angulo -= Math.PI/2;
	 }
	 var now = new Date();
//  	 console.log(" Dibujando >"+(now-then)+"ms",'TIME');
  },
  movewheel: function(objEvent,intDelta){
	 if (intDelta > 0){
		this.intOverallDelta++;
		this.aumentar();
		this.mover((objEvent.clientX-200)/40,(objEvent.clientY-200)/40);
	 }
	 else if (intDelta < 0){
		this.intOverallDelta--;
		this.disminuir();
		this.mover((objEvent.clientX-200)/40,(objEvent.clientY-200)/40);
	 }
	 this.pintar();
  }
};

var objDragon;
$(document).ready(function(){
  objDragon = new Dragon('MiCanvas');
  objDragon.pintar();
   $('#MiCanvas').mousewheel(function(objEvent,intDelta){objDragon.movewheel(objEvent,intDelta);});
  $('#MiCanvas').mouseup(function(e){objDragon.clickmouseup(e);});
  $('#MiCanvas').mousedown(function(e){objDragon.clickmousedown(e);});  
   $('#MiCanvas').dblclick(function(){objDragon.fractalizar();});
});