# $Id: README.txt,v 1.5 2008/07/15 23:59:36 merlinofchaos Exp $

Welcome to Panels 2.

A little documentation should go here, but Panels 2 is a beast - you're best
off checking the online handbook on Drupal.org, or the developer/API docs,
which are available at http://doxy.samboyer.org/panels2/ 
