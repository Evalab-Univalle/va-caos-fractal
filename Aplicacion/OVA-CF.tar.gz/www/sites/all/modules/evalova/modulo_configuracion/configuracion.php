<?php
ini_set('display_errors', 1);
require_once("Configuracion.inc");
$parametrosConexion = array("con_servidor" => "localhost",
									 "con_usuario" => "root",
									 "con_password" => "root",
									 "con_nombre_bd" => "ova-cf");
$objetoConfiguracion = new Configuracion($parametrosConexion);

switch($_REQUEST['accion']){
	case 'adicionarTest':
		if($_REQUEST['tes_nombre']!='')
			echo is_numeric($objetoConfiguracion->adicionarTest($_REQUEST['tes_nombre']));
		else
			echo false;
  break;
	case 'cargarTests':
		echo $objetoConfiguracion->cargarTests();
  break;
  case 'cargarRepositorio':
		echo $objetoConfiguracion->cargarRepositorio($_REQUEST['tes_id']);
  break;
  case 'cargarContenidoPregunta':
	 echo json_encode($objetoConfiguracion->cargarContenidoPregunta($_REQUEST['pre_id']));
  break;
	case 'adicionarPregunta':
		$texto = $_REQUEST['pre_texto'];
		if($texto != '')
			$pre_id = $objetoConfiguracion->adicionarPregunta(addslashes($texto),$_REQUEST['tes_id'],'NULL','NULL');
		echo is_numeric($pre_id);
	break;
  case 'adicionarPregunta1':
	 $texto = $_REQUEST['pre_texto'];
	 $cantidad= $_REQUEST['pre_cantidad_respuestas_visibles'];
	 $peso= $_REQUEST['pre_peso'];
	 if(!is_numeric($cantidad))
		$cantidad = 'null';
	 if(!is_numeric($peso))
		$peso = 'null';

	 if($texto != '')
		$pre_id = $objetoConfiguracion->adicionarPregunta(addslashes($texto),$cantidad,$peso);
	 else
		echo false;


	 $res_textos = (array)json_decode(stripslashes($_REQUEST['res_textos']));
	 $res_puntuaciones = (array)json_decode(stripslashes($_REQUEST['res_puntuaciones']));
	 $res_ordenes = (array)json_decode(stripslashes($_REQUEST['res_ordenes']));
	 $res_id = '';

 	 if(is_numeric($pre_id)){
		for($i = 0;$i<count($res_textos);$i++){
		  $texto = $res_textos[$i];
		  $puntuacion = $res_puntuaciones[$i];
		  $orden = $res_ordenes[$i];

		  if(!is_numeric($puntuacion))
			 $puntuacion = 'NULL';
		  if($orden=='true')
			 $orden = $i+1;
		  else
			 $orden = 'NULL';

		  if($texto!='')
			$res_id = $objetoConfiguracion->adicionarRespuesta($pre_id,addslashes($texto),$orden,$puntuacion);
		}
	 }
	 echo is_numeric($pre_id);
	 
  break;
  case 'eliminarPregunta':
	 echo $objetoConfiguracion->eliminarPregunta($_REQUEST['pre_id']);
  break;
  case 'eliminarRespuesta':
	 echo $objetoConfiguracion->eliminarRespuesta($_REQUEST['res_id']);
  break;
  case 'cargarContenidoRespuestas':
	 echo $objetoConfiguracion->cargarContenidoRespuestas($_REQUEST['pre_id']);
  break;

  case 'guardarRespuestas':
	 $pre_id = '';
	 if(is_numeric($_REQUEST['pregunta_id']))
		$pre_id = $_REQUEST['pregunta_id'];

	 if(is_numeric($pre_id)){

		$objetoConfiguracion->eliminarRespuestas($pre_id);
		$res_textos = (array)json_decode(stripslashes($_REQUEST['res_textos']));
		$res_puntuaciones = (array)json_decode(stripslashes($_REQUEST['res_puntuaciones']));
		$res_ordenes = (array)json_decode(stripslashes($_REQUEST['res_ordenes']));
 	 
		for($i = 0;$i<count($res_textos);$i++){
		  $texto = $res_textos[$i];
		  $puntuacion = $res_puntuaciones[$i];
		  $orden = $res_ordenes[$i];

		  if(!is_numeric($puntuacion))
			 $puntuacion = 'NULL';
		  if($orden=='true')
			 $orden = $i+1;
		  else
			 $orden = 'NULL';

		  if($texto!='')
			$res_id = $objetoConfiguracion->adicionarRespuesta($pre_id,addslashes($texto),$orden,$puntuacion);
		}
	 }
	 echo is_numeric($res_id);
  break;
	case 'actualizarPregunta_pre_peso':
		$var = $_REQUEST['variable'];
		if(!is_numeric($var))$var = 'null';
		$objetoConfiguracion->actualizarPesoPregunta($var,$_REQUEST['pre_id']);
	break;
	case 'actualizarPregunta_pre_cantidad_respuestas_visibles':
		$var = $_REQUEST['variable'];
		if(!is_numeric($var))$var = 'null';
		$objetoConfiguracion->actualizarCantidadPregunta($var,$_REQUEST['pre_id']);
	break;
  case 'actualizarTextoPregunta':
		echo is_numeric($objetoConfiguracion->actualizarTextoPregunta(addslashes($_REQUEST['pre_texto']),$_REQUEST['pre_id']));
	break;
	case 'adicionarRespuesta':
		echo is_numeric($objetoConfiguracion->adicionarRespuesta($_REQUEST['res_pre_id'],addslashes($_REQUEST['res_texto'])));
	break;
	case 'actualizarRespuesta_res_puntuacion':
		$var = $_REQUEST['variable'];
		if(!is_numeric($var))$var = 'null';
		$objetoConfiguracion->actualizarPuntuacionRespuesta($var,$_REQUEST['res_id']);
	break;
	case 'actualizarRespuesta_res_orden':
		$var = $_REQUEST['variable'];
		if(!is_numeric($var))$var = 'null';
			$objetoConfiguracion->actualizarOrdenRespuesta($var,$_REQUEST['res_id']);
	break;	
	case 'actualizarRespuesta_res_tema':
		$var = $_REQUEST['variable'];
		if(!is_numeric($var))$var = 'null';
			$objetoConfiguracion->actualizarTemaRespuesta($var,$_REQUEST['res_id']);
	break;
	case 'actualizarTextoRespuesta':
		echo is_numeric($objetoConfiguracion->actualizarTextoRespuesta(addslashes($_REQUEST['res_texto']),$_REQUEST['res_id']));
	break;
}