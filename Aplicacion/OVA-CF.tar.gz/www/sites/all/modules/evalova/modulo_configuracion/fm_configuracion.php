<?php
/*
echo ;
global $db_url;
var_dump($db_url);
global $db_type;
var_dump($db_type);*/
global $language;
$html = new GeneradorHtml();
$html->idioma = $language->language;
$html->cargarHerramientaJS("sites/all/modules/evalova/herramientas/jquery-1.4.2.min");
$html->cargarHerramientaJS("sites/all/modules/evalova/herramientas/jquery.tablednd_0_5");
$html->cargarHerramientaJS("sites/all/modules/evalova/herramientas/jquery.json-2.2.min");
$html->cargarHerramientaJS("sites/all/modules/evalova/modulo_configuracion/configuracion");
$html->tag("link",array('rel'=>"stylesheet",'type'=>"text/css",'href'=>"sites/all/modules/evalova/estilos/evaluacion.css"),true);

$html->tag("div",array("id"=>"div_test"));
	$html->tag("table", array("class"=>"ancho_formulario"));
		$html->tag("tr");
			$html->tag("td", array("class"=>"alineacion_centro"));
				$html->tag("div",array("id"=>"lbl_mensaje"));
				$html->end("label");
			$html->end("td");
		$html->end("tr");
	
		$html->tag("tr");
			$html->tag("td");
			
				$html->tag("fieldset");
					$html->tag("legend");
						$html->tag("label");
							$html->printText("Tests");
						$html->end("label"); 
					$html->end("legend"); 
					
					$html->tag("table");
						$html->tag("tr");
							$html->tag("td", array("class"=>"ancho_td_label"));
								$html->tag("label", array("class"=>"label_formulario"));
									$html->printText("Nombre : ");
								$html->end("label"); 
							$html->end("td");
								
							$html->tag("td");
								$html->tag("input",array("id"=>"tes_texto", "input"=>"text", "title"=>"Nombre del test que se agregará al repositorio"),true);
								$html->espacios(2);
								$html->tag("button",array('onclick'=>'adicionarTest()', "title"=>"Adiciona este test al repositorio", "class"=>"btn_imagen vertical_centro"));
									$html->tag("img", array("class"=>"img_boton", "src"=>"sites/all/modules/evalova/imagenes/add.png"));
								$html->end("button");
							$html->end("td");
						$html->end("tr");
					$html->end("table");

					$html->tag("table");
						$html->tag("tr");
							$html->tag("td", array("class"=>"ancho_td_label"));
								$html->tag("label", array("class"=>"label_formulario"));
									$html->printText("Nombre : ");
								$html->end("label"); 
							$html->end("td");
								
							$html->tag("td");
								$html->tag("select",array("id"=>"tes_nombre", "title"=>"Nombre del test"));
									$html->tag("option");
										$html->printText("Cargando...");
									$html->end("option");
								$html->end("select");
							$html->end("td");
						$html->end("tr");
					$html->end("table");
					
				$html->end("fieldset");
				
			$html->end("td");
		$html->end("tr");
	$html->end("table");
$html->end("div");

$html->tag("div",array("id"=>"div_repositorio"));
	$html->tag("table", array("class"=>"ancho_formulario"));
	
		$html->tag("tr");
			$html->tag("td");
			
				$html->tag("fieldset");
					$html->tag("legend");
						$html->tag("label");
							$html->printText("Cuestionario");
						$html->end("label"); 
					$html->end("legend"); 
					
					$html->tag("table");
						$html->tag("tr");
							$html->tag("td", array("class"=>"ancho_td_label"));
								$html->tag("label", array("class"=>"label_formulario"));
									$html->printText("Enunciado");
								$html->end("label"); 
							$html->end("td");
								
							$html->tag("td");
								$html->tag("input",array("id"=>"pre_texto", "input"=>"text", "title"=>"Enunciado de la pregunta que se agregará al repositorio de preguntas"),true);
								$html->espacios(2);
								$html->tag("button",array('onclick'=>'adicionarPregunta()', "title"=>"Adiciona este enunciado al repositorio de preguntas", "class"=>"btn_imagen vertical_centro"));
									$html->tag("img", array("class"=>"img_boton", "src"=>"sites/all/modules/evalova/imagenes/add.png"));
								$html->end("button");
							$html->end("td");
						$html->end("tr");
					$html->end("table");
						
					$html->tag("table", array("id"=>"tbl_cuestionario"));
						$html->tag("thead");
							$html->tag("th", array("class"=>"alineacion_centro"));
								$html->tag("label");
									$html->printText("Pregunta");
								$html->end("label"); 
							$html->end("th");
							
							$html->tag("th");
								$html->tag("label", array("class"=>""));
									$html->printText("Peso");
								$html->end("label"); 
							$html->end("th");
							
							$html->tag("th");
								$html->tag("label", array("class"=>""));
									$html->printText("Respuestas visibles");
								$html->end("label"); 
							$html->end("th");
							
							 $html->tag("th");
								  $html->tag("label");
									 $html->printText("Tema");
								  $html->end("label"); 
							 $html->end("th");

							$html->tag("th");
								$html->tag("label", array("class"=>""));
									$html->printText("Editar");
								$html->end("label"); 
							$html->end("th");

							$html->tag("th");
								$html->tag("label", array("class"=>""));
									$html->printText("Eliminar");
								$html->end("label"); 
							$html->end("th");
						$html->end("thead");

						$html->tag("tbody");
						$html->end("tbody");

					$html->end("table");
					
				$html->end("fieldset");
				
			$html->end("td");
		$html->end("tr");
	$html->end("table");
$html->end("div");

$html->tag("div",array("id"=>"div_edicion"));
	 $html->tag("table",array("class"=>"ancho_formulario"));
		
		$html->tag("tr");	
			$html->tag("td");
			
				$html->tag("fieldset");
					$html->tag("legend");
						$html->tag("label");
							$html->printText("Respuesta de la pregunta");
						$html->end("label"); 
					$html->end("legend"); 
			
					$html->tag("table");
						$html->tag("tr");
							$html->tag("td", array("class"=>"ancho_td_label"));
								$html->tag("label", array("class"=>"label_formulario"));
									$html->printText("Enunciado");
								$html->end("label");
							$html->end("td");
							
							$html->tag("td");
								$html->tag("input",array("id"=>"res_texto", "type"=>"text",'disabled'=>'disabled', "title"=>"Enunciado de la respuesta que se agregará al repositorio de respuestas", "class"=>"vertical_centro"),true);
								$html->espacios(2);
								$html->tag("button",array('id'=>'btn_addRespuesta','disabled'=>'disabled','onclick'=>'adicionarRespuesta()', "title"=>"Adiciona este enunciado al repositorio de respuestas", "class"=>"btn_imagen vertical_centro"));
									$html->tag("img", array("class"=>"img_boton", "src"=>"sites/all/modules/evalova/imagenes/add_off.png"));
								$html->end("button");
							$html->end("td");
						$html->end("tr");
												
						$html->tag("tr");

							$html->tag("td", array("colspan"=>"2"));
							
								$html->br(1);
								$html->tag("label", array("class"=>"label_formulario_2"));
									$html->printText("Repositorio de respuestas a la pregunta");
								$html->end("label"); 
								$html->br(1);
								
								$html->tag("table", array("id"=>"tbl_respuestas"));
								
									$html->tag("thead");
										$html->tag("th", array("class"=>"ancho_270"));
											$html->tag("label");
												$html->printText("Respuesta");
											$html->end("label"); 
										$html->end("th");
										
										$html->tag("th");
											$html->tag("label");
												$html->printText("Peso");
											$html->end("label"); 
										$html->end("th");
										
										$html->tag("th");
											$html->tag("label");
												$html->printText("Fija");
											$html->end("label"); 
										$html->end("th");

										
										$html->tag("th");
											$html->tag("label");
												$html->printText("Editar");
											$html->end("label"); 
										$html->end("th");

									$html->tag("th");
											$html->tag("label");
												$html->printText("Eliminar");
											$html->end("label"); 
										$html->end("th");
									$html->end("thead");
									
									$html->tag("tbody");
									$html->end("tbody");
								$html->end("table");
							$html->end("td");
						$html->end("tr");
					$html->end("table");
					
				$html->end("fieldset");
					
			$html->end("td");
		$html->end("tr");
	$html->end("table");
$html->end("div");
?>