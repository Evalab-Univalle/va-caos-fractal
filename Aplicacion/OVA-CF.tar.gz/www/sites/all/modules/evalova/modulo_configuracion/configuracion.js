$(document).ready(inicializar);
var pregunta_id='';
var test_id='';

function inicializar(){
	$('#boton_actualizar').hide();
	url_controlador_modulo = "sites/all/modules/evalova/modulo_configuracion/configuracion.php";	
	activarAgregarPregunta(false);
	cargarTests();
	$('#div_edicion').click(function(){if($("input[name='pre_texto_tmp']").length>0)finEditarPreTexto($("input[name='pre_texto_tmp']"));});
	$('#tes_nombre').change(function(){test_id = $(this).val();nuevaPregunta();cargarRepositorio(test_id);});	
}

function cargarTests(){
	activarAgregarPregunta(false);
	$.post(url_controlador_modulo,{'accion':'cargarTests'},function(datos){
 		if(datos=='')
			activarAgregarPregunta(false);
		else
			activarAgregarPregunta(true);
		$('#tes_nombre').html(datos).change();
	 });
}

function cargarRepositorio(tes_id){
	$.post(url_controlador_modulo,{'accion':'cargarRepositorio','tes_id':tes_id},function(datos){
 		$('#tbl_cuestionario tbody').html(datos);
		activarAgregarRespuesta(false);
		eventosPreguntas();
	 });
}

function eventosPreguntas(){	
	$("#div_repositorio [name='pre_cantidad_respuestas_visibles']").unbind('change').change(function(){autoguardadoPregunta($(this),'pre_cantidad_respuestas_visibles');});
	$("#div_repositorio [name='pre_peso']").unbind('change').change(function(){autoguardadoPregunta($(this),'pre_peso');});
	$('#div_repositorio [name="pre_texto"]:visible').unbind('dblclick').dblclick(function(){editarPreTexto($(this));});
}

function eventosRespuestas(){
  $('#tbl_respuestas').tableDnD();
	$('#tbl_respuestas').tableDnD({onDrop:guardarRespuestas});
	$("#tbl_respuestas [name='res_puntuacion']").unbind('change').change(function(){autoguardadoRespuesta($(this),'res_puntuacion');});
	$("#tbl_respuestas [name='res_orden']").unbind('change').change(function(){guardarRespuestas();});
	$("#tbl_respuestas [name='res_tema']").unbind('change').change(function(){autoguardadoRespuesta($(this),'res_tema');});
  $('#tbl_respuestas [name="res_texto"]:visible').unbind('dblclick').dblclick(function(){editarResTexto($(this));});
}

function autoguardadoPregunta(obj,variable){
	pre_id = $(obj.parent().parent()).attr('id').substring(3);
	nuevo = obj.attr('value');	
	$.post(url_controlador_modulo,{'accion':'actualizarPregunta_'+variable,'pre_id':pre_id,'variable':nuevo});
}

function autoguardadoRespuesta(obj,variable){
	res_id = $(obj.parent().parent()).attr('name').substring(3);
	nuevo = obj.attr('value');
	$.post(url_controlador_modulo,{'accion':'actualizarRespuesta_'+variable,'res_id':res_id,'variable':nuevo});
}

function editarPreTexto(obj){
  objtd = obj.parent();
  txt = obj.html();  
  $(objtd).html('<input type="text" name="pre_texto_tmp" value="'+txt+'">');
	$('#div_repositorio [name="pre_texto_tmp"]:visible').blur(function(){finEditarPreTexto($(this));});
}

function finEditarPreTexto(obj){
  objtd = obj.parent();
  txt = obj.attr('value');
	pre_id = objtd.parent().attr('id').substring(3);
  $(objtd).html('<label name="pre_texto" class="enunciado">'+txt+'</label>');
	$.post(url_controlador_modulo,{'accion':'actualizarTextoPregunta','pre_id':pre_id,'pre_texto':txt},function(){
		});
  eventosPreguntas();
}

function adicionarTest(){
  tes_texto = $('#tes_texto').attr('value');
	if(tes_texto != '')
	 $.post(url_controlador_modulo,{'accion':'adicionarTest','tes_nombre':tes_texto},function(datos){
			if(datos=='1'){
				mensaje('Test agregado con exito',true);
				cargarTests();
			}
			else{
				mensaje('Error : '+datos,false);
			}
		});
	$('#pre_texto').attr('value','');
}

function adicionarPregunta(){
  pre_texto = $('#pre_texto').attr('value');
	if(pre_texto != '')
	 $.post(url_controlador_modulo,{'accion':'adicionarPregunta','pre_texto':pre_texto,'tes_id':test_id},function(datos){
			console.log(datos,'data');if(datos=='1'){
				mensaje('Pregunta adicionada',datos);
				cargarRepositorio(test_id);
			}
			else{
				mensaje('Error',datos);
			}
		});
	$('#pre_texto').attr('value','');
}

function adicionarRespuesta(){
  res_texto = $('#res_texto').attr('value');
	if(res_texto != '')	 
	 $.post(url_controlador_modulo,{'accion':'adicionarRespuesta','res_texto':res_texto,'res_pre_id':pregunta_id},function(datos){
			if(datos=='1'){
				mensaje('Respuesta adicionada',datos);
				cargarContenidoRespuestas(pregunta_id);
			}
			else{
				mensaje('Error',datos);
			}
		});
	$('#res_texto').attr('value','');
}

function mensaje(msj,estado){
	if(estado)
		$('#lbl_mensaje').addClass('status').html(msj);
	else
		$('#lbl_mensaje').addClass('error').html(msj);
	setTimeout("mensajeVacio()",5000);
}
function mensajeVacio(){
	$('#lbl_mensaje').html('').removeClass('status').removeClass('error');
}

function editarPregunta(pre_id){
		$('#pre'+pre_id+" [name='pre_texto']").dblclick();
		cargarContenidoRespuestas(pre_id);
		pregunta_id = pre_id;
		activarAgregarRespuesta(true);
}

function activarAgregarRespuesta(activa){
	if(activa){
		$('#res_texto').removeAttr('disabled');
		$('#btn_addRespuesta').removeAttr('disabled');
		$('#btn_addRespuesta img').attr('src','sites/all/modules/evalova/imagenes/add.png');
	}
	else{
		$('#res_texto').attr('disabled','disabled');
		$('#btn_addRespuesta').attr('disabled','disabled');
		$('#btn_addRespuesta img').attr('src','sites/all/modules/evalova/imagenes/add_off.png');
	}
}

function activarAgregarPregunta(activa){
	if(activa){
		$('#pre_texto').removeAttr('disabled');
		$('#btn_addPregunta').removeAttr('disabled');
		$('#btn_addPregunta img').attr('src','sites/all/modules/evalova/imagenes/add.png');
	}
	else{
		$('#pre_texto').attr('disabled','disabled');
		$('#btn_addPregunta').attr('disabled','disabled');
		$('#btn_addPregunta img').attr('src','sites/all/modules/evalova/imagenes/add_off.png');
	}
}

function editarRespuesta(res_id){
  editarResTexto($('#tbl_respuestas [name="res'+res_id+'"] label'));
}



function editarResTexto(obj){
  objtd = obj.parent();
  txt = obj.html();  
  $(objtd).html('<input type="text" name="res_texto_tmp" value="'+txt+'">');
	$('#tbl_respuestas [name="res_texto_tmp"]:visible').blur(function(){finEditarResTexto($(this));});
}

function finEditarResTexto(obj){
  objtd = obj.parent();
  txt = obj.attr('value');
	res_id = objtd.parent().attr('name').substring(3);
  $(objtd).html('<label name="res_texto" class="enunciado">'+txt+'</label>');  
	$.post(url_controlador_modulo,{'accion':'actualizarTextoRespuesta','res_id':res_id,'res_texto':txt},function(){
		});
	eventosRespuestas();
}

function cargarContenidoRespuestas(pre_id){
  $.post(url_controlador_modulo,{'accion':'cargarContenidoRespuestas','pre_id':pre_id},function(datos){
	 $('#tbl_respuestas tbody').html(datos);
	 eventosRespuestas();
  });
}

function eliminarRespuesta(res_id){
    var res=confirm("¿Esta seguro de eliminar la respuesta?");
	 if (res){
			 $('#tbl_respuestas [name="res'+res_id+'"]').hide();
 			 cargarContenidoRespuestas(pregunta_id);
		  }
}

function eliminarPregunta(pre_id){
  var res=confirm("¿Esta seguro de eliminar la pregunta?");
  if (res)
	 $.post(url_controlador_modulo,{'accion':'eliminarPregunta','pre_id':pre_id},function(datos){
		if(datos==1){
			 mensaje('La pregunta fue eliminada satisfactoriamente',true);
			 cargarRepositorio(test_id);
		  }
	 });
}

function nuevaPregunta(){	
  $('#pre_texto').attr('value','');
  $('#pre_cantidad_respuestas_visibles').attr('value','');
  $('#pre_peso').attr('value','');
  $('#tbl_respuestas tbody').html('')
  $('#res_texto').attr('value','');
  $('#boton_actualizar').hide();
  $('#boton_adicionar').show();
  pregunta_id = '';
}

function guardarRespuestas(){  
  arreglohtmlres_texto = $('#tbl_respuestas [name="res_texto"]:visible');
  res_textos = Array();
  for(i=0;i<arreglohtmlres_texto.length;i++){
	 res_textos.push($(arreglohtmlres_texto[i]).html());
  }

  arreglohtmlres_puntuacion = $('#tbl_respuestas [name="res_puntuacion"]:visible');
  res_puntuaciones = Array();
  for(i=0;i<arreglohtmlres_puntuacion.length;i++){
	 res_puntuaciones.push($(arreglohtmlres_puntuacion[i]).attr('value'));
  }

  arreglohtmlres_orden = $('#tbl_respuestas [name="res_orden"]:visible');
  res_ordenes = Array();
  for(i=0;i<arreglohtmlres_orden.length;i++){
	 res_ordenes.push($(arreglohtmlres_orden[i]).attr('checked'));
  }

	$.post(url_controlador_modulo,{'accion':'guardarRespuestas','res_textos':$.toJSON(res_textos),'res_puntuaciones':$.toJSON(res_puntuaciones),'res_ordenes':$.toJSON(res_ordenes),'pregunta_id':pregunta_id},function(datos){
	if(datos==1){
		mensaje('La pregunta ha sido agregada/actuaizada satisfactoriamente',true);
		
	}
	else
		mensaje('ERROR : '+datos,false);
	});  
}





