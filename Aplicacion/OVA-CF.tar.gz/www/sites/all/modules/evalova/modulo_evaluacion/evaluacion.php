<?php
ini_set('display_errors', 1);
require_once("../herramientas/ConexionBDMySQL.inc");
require_once("../herramientas/GeneradorHtml.inc");
require_once('../FirePHPCore/FirePHP.class.php');
ob_start();
$firephp = FirePHP::getInstance(true);
$firephp->log(':)', 'Iterators');
function debug($var,$msg=''){
	global $firephp;
	$firephp->log($var, $msg);//echo "<br/> $msg => $var <br/>";
}
$parametrosConexion = array("con_servidor" => "localhost",
									 "con_usuario" => "root",
									 "con_password" => "root",
									 "con_nombre_bd" => "ova-cf");
		$conexionBD = new ConexionBDMySQL($parametrosConexion);
		$conexionBD->conectar();
switch($_REQUEST['accion']){
  case 'calificar':
		$data = (array)json_decode(stripslashes($_REQUEST['data']));
		if(count($data)<=0)
			die();

		$sql = "SELECT tes_id FROM evalova_test,evalova_pregunta WHERE pre_tes_id = tes_id AND pre_id = ".key($data);
		$conexionBD->ejecutarSQL($sql);//echo $sql;
		$tes_id = '';
		while($rs = $conexionBD->obtenerFilaComoArregloAsociativo()){
			$tes_id = $rs['tes_id'];
		}
		foreach($data as $k => $v)
			$data2[intval($k)]=intval($v);
		$data = $data2;
		$sql = "select * from evalova_pregunta LEFT JOIN evalova_respuesta ON(pre_id = res_pre_id)  JOIN evalova_test ON(tes_id = '$tes_id' AND tes_id = pre_tes_id);";
		$conexionBD->ejecutarSQL($sql);//echo $sql;
		$mayor=0;
		$primera=true;
		$ultimopre_id=0;
		$pre_peso = 0;
		$pesoTotal = 0;
		$puntuacionTotal = 0;
		$puntuacionEstudiante = 0;
		$temas = array();
		while($rs = $conexionBD->obtenerFilaComoArregloAsociativo()){
			if($primera){
				$primera = false;
				$ultimopre_id = $rs['pre_id'];
			}
			if($ultimopre_id!=$rs['pre_id']){
				$puntuacionTotal+= ($mayor * intval($pre_peso));
				$ultimopre_id = $rs['pre_id'];
				$pre_peso = 0;
			}
			
			if(isset($data2[$rs['pre_id']])){
					if($data2[$rs['pre_id']] == $rs['res_id']){
						$puntuacionEstudiante+=intval($rs['res_puntuacion'])*intval($rs['pre_peso']);}
				}

			$pre_peso = $rs['pre_peso'];

			if($mayor<$rs['res_puntuacion'])
				$mayor=$rs['res_puntuacion'];

		}
		if(!$primera){
				$puntuacionTotal+= ($mayor * intval($pre_peso));
		}
		$cantidadPreguntas = count($data);
		$calificacion = ($puntuacionEstudiante / $puntuacionTotal)*100;
		debug($calificacion,'CAL');
  break;  
}
