$(document).ready(inicializar);

function inicializar(){
	$("input[type='radio']").attr('checked',false);
	url_controlador_modulo = "sites/all/modules/evalova/modulo_evaluacion/evaluacion.php";
}

function calificar(){
	respuestas = $("input[type='radio']:checked");
	pre_res = {};
	for(i=0;i<respuestas.length;i++){
		divres = $(respuestas[i]).parent().parent();
		resid = divres.attr('id').substring(13);
		divpre = divres.parent();
		preid = divpre.attr('id').substring(12);
		pre_res[preid] = resid;
	}
	console.log(pre_res);
	$.post(url_controlador_modulo,{'accion':'calificar','data':$.toJSON(pre_res)},function(){
			
		});
}