// $Id: README.txt,v 1.3 2006/12/23 15:35:51 dries Exp $

This directory should be used to place downloaded and custom modules
and themes which are common to all sites. This will allow you to
more easily update Drupal core files. These modules and themes should
be placed in subdirectories called modules and themes as follows:

  sites/all/modules
  sites/all/themes
