<?php // $Id $ ?>
<?php echo art_navigation_links_worker($block->content); ?>